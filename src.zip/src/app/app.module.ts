import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';
import { Profile } from '../pages/profile/profile';
import { Categoryitems } from '../pages/categoryitems/categoryitems';
import { Home1 } from '../pages/home1/home1';
import { Signin } from '../pages/signin/signin';
import { SignupPage } from '../pages/signup/signup';
import { Login } from '../pages/login/login';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { IonicStorageModule  } from '@ionic/storage';
import { Dataservice } from '../providers/dataservice';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    ListPage,
    Profile,
    Categoryitems,
    Home1,
    Signin,
    SignupPage,
    Login
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    IonicStorageModule.forRoot({
      name: '__misplaces',
      driverOrder: ['indexeddb', 'sqlite', 'websql']
    })
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    ListPage,
    Profile,
    Categoryitems,
    Home1,
    Signin,
    SignupPage,
    Login     
  ],
  providers: [
    StatusBar,
    SplashScreen,
    Dataservice,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}

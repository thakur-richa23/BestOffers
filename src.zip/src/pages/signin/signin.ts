import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HomePage } from '../home/home';
import { SignupPage } from '../signup/signup';
import { Login } from '../login/login';

@IonicPage()
@Component({
  selector: 'page-signin',
  templateUrl: 'signin.html',
})
export class Signin {
  SignupPage:any;
  Login:any;
 icons: string[];
 name:string[];
  items: Array<{title: string,icon: string}>;
ngOnInit(){
    // Let's populate this page with some filler content for funzies
    this.icons = ['person', 'information-circle', 'mail'];
    this.name=['Profile','About','Contact']
    this.items = [];
    for (let i = 0; i < 3; i++) {
      this.items.push({
        title: this.name[i],
        icon: this.icons[i]
      });
    }
}
  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  signup(){
   this.navCtrl.push(SignupPage);
  }
  login(){
    this.navCtrl.push(Login);
  }
}

import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the Categoryitems page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-categoryitems',
  templateUrl: 'categoryitems.html',
})
export class Categoryitems {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  

}

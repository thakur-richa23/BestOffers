import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Profile } from '../profile/profile';
import {Tabs} from "ionic-angular";
import { Home1 } from '../home1/home1';
import { Signin } from '../signin/signin';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
 
  tab1 =Home1;
  tab2 = Profile;
  tab3= Signin;
IsHidden:any=true;
tabtext:any;
  constructor(public navCtrl: NavController, private storage: Storage) {  
    this.tabtext = false;
  }

  searchbtn(){
   this.IsHidden = this.IsHidden == true ? false : true;

  }
  backbtn(){
    this.navCtrl.setRoot(this.navCtrl.getActive().component);
  }

}

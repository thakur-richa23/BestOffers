import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HomePage } from '../home/home';

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class Login {
 IsHidden:any= true;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.IsHidden = this.IsHidden == true ? false : true;
  }

  
}
